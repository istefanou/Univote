package johnara.com.univote;

public class Katigoria {
    private String Titlos;

    public Katigoria(String titlos) {
        this.Titlos = titlos;
    }

    public String getTitlos() {
        return Titlos;
    }

}
